import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.sound.sampled.*;

//Saner Turhaner

public class MainMenuPanelReader extends EventReader 
{			
	//Constructor
	public MainMenuPanelReader(ViewFacade given, ControllerFacade given2)
	{ 
		super(given, given2);
	}
	
	//Function
	public void actionPerformed(ActionEvent event)//Takes event as a parameter
	{
		obj = event.getSource();
		
		try//Try it
    	{
    		if(obj == ((MainMenuPanel)(frame.activePanel)).newGame)
			{
				( (MainMenuPanel)(frame.activePanel) ).music.stopMusic();
				GameScreenPanel newPanel =  new GameScreenPanel(frame);
				newPanel.restart();
				frame.setpanel( newPanel );
			}
			if(obj == ((MainMenuPanel)(frame.activePanel)).password)
			{
				frame.setpanel( new LoadLevelPanel(frame, ((MainMenuPanel)(frame.activePanel)).music) );
			}
			if(obj == ((MainMenuPanel)(frame.activePanel)).highScores)
			{
				frame.setpanel( new HighScoresPanel(frame, ((MainMenuPanel)(frame.activePanel)).music) );
			}
			if(obj == ((MainMenuPanel)(frame.activePanel)).credits)
			{
				frame.setpanel( new CreditsPanel(frame, ((MainMenuPanel)(frame.activePanel)).music) );
			}	
			if(obj == ((MainMenuPanel)(frame.activePanel)).exit)
			{
				((MainMenuPanel)(frame.activePanel)).music.stopMusic();
				frame.exit();//Exit from frame
			}
    	}	
    	catch(Exception exc)//If there is exception (general) catch it
    	{    		
    		System.out.println("Exception is catched: " + exc.getMessage());//Show the message of exception
    	}										
	}
}