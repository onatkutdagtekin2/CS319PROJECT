import java.util.*;
import java.awt.*;
import javax.swing.*;

//Saner Turhaner

public class ModelFacade 
{	
	//Variables
   	ArrayList<GameObject> objects;
   	BackGround background;
    
    //Stars
   	ArrayList<CloseStar> closestars;
   	ArrayList<FarStar> farstars;
   	
   	//Ships
   	PlayerShip playership;
   	ArrayList<EnemyShip> enemyships;
   	
   	
   	//Constructor
	public ModelFacade()
	{	
		objects = new ArrayList<GameObject>();
		//enemyships = new ArrayList<EnemyShip>();
		initializeData();
	}	
	
	//Necessary Methods
	public void initializeData()
	{
		//Backgroung
		background = new BackGround();
		objects.add(background);
		
		//Stars
		closestars = new ArrayList<CloseStar>();
		farstars = new ArrayList<FarStar>();
		createStars();
		
		//PlayerShip
		playership = new PlayerShip(3, 0);
		objects.add(playership);
		
		//EnemyShips
		enemyships = new ArrayList<EnemyShip>();
		createEnemies();					
	}
	
	public void createEnemies()//Create enemies
	{		
		//Create close stars
		for(int i = 0; i < 10; i++)
			enemyships.add(new EnemyShip());
	}
	
	public void drawEnemies(Graphics g)//Draw all enemies
	{
		for(int i = 0; i < enemyships.size(); i++)
			enemyships.get(i).draw(g);
	}
	
	public void moveEnemies()//Move all enemies
	{
		for(int i = 0; i < enemyships.size(); i++)
		{				
			if( (double)i % 2 == 0 )
				enemyships.get(i).movement();			
			else
				enemyships.get(i).movement2();
		}
	}
		
	public void drawEnemyBullets(Graphics g)//Draw all objects
	{		
		for(int i = 0; i < enemyships.size(); i++)
			enemyships.get(i).drawBullets(g);
	}
	
	public void checkEnemyBullets(PlayerShip ship, Graphics g)
	{		
		for(int i = 0; i < enemyships.size(); i++)
		{
			(enemyships.get(i)).checkCollisionForPlayer(ship, g);
		}
	}
	
	public void checkPlayerBullets(PlayerShip ship, Graphics g)
	{		
		for(int i = 0; i < enemyships.size(); i++)
		{
			(enemyships.get(i)).checkCollisionForEnemy(ship, g);
			checkEnemyLife(ship, i);
		}
		
	}
	
	public void checkEnemyLife(PlayerShip ship, int i)
	{		
		if(enemyships.get(i).health <= 0)
		{
			for(int j = 0; j < enemyships.get(i).bullets.size(); j++)
			{
				enemyships.get(i).bullets.get(j).soundEffect.stopMusic();
			}
			enemyships.remove(i);
			ship.gainPoint();
		}
	}
	
	public void checkPlayerLife(Graphics g)
	{		
		if(playership.health <= 0)
		{
			playership.die();
			playership = new PlayerShip(playership.life, playership.points);
		}		
		if(playership.fuel <= 0)
		{
			playership.die();
			playership = new PlayerShip(playership.life, playership.points);
		}
		
		playership.drawLives(g);
	}
	
	public void createStars()//Create Stars
	{		
		//Create close stars
		for(int i = 0; i < 2500; i++)
			closestars.add(new CloseStar());
						
		//Create far stars	
		for(int i = 0; i < 1000; i++)
			farstars.add(new FarStar());
	}
	
	public void drawStars(Graphics g)//Draw all stars
	{
		for(int i = 0; i < farstars.size(); i++)
			farstars.get(i).draw(g);
		for(int i = 0; i < closestars.size(); i++)
			closestars.get(i).draw(g);
	}
	
	public void moveStars()//Move all stars
	{
		for(int i = 0; i < farstars.size(); i++)
			farstars.get(i).move();
		for(int i = 0; i < closestars.size(); i++)
			closestars.get(i).move();
	}
	
	public void draw(Graphics g)//Draw all objects
	{
		for(int i = 0; i < objects.size(); i++)
			objects.get(i).draw(g);
	}
	
	public void addclosetolist(ArrayList<CloseStar> list)//Add elements of list
	{
		for(int i = 0; i < list.size(); i++)
			objects.add(list.get(i));
	}	
	
	public void addfartolist(ArrayList<FarStar> list)//Add elements of list
	{
		for(int i = 0; i < list.size(); i++)
			objects.add(list.get(i));
	}	
	
	public void stopMusics()//Add elements of list
	{
		for(int i = 0; i < enemyships.size(); i++)
		{
			for(int j = 0; j < enemyships.get(i).bullets.size(); j++)
				enemyships.get(i).bullets.get(j).soundEffect.stopMusic();
		}
		
		for(int i = 0; i < playership.bullets.size(); i++)
		{
			playership.bullets.get(i).soundEffect2.stopMusic();
		}
	}
	
	public void playMusics()//Add elements of list
	{
		for(int i = 0; i < enemyships.size(); i++)
		{
			for(int j = 0; j < enemyships.get(i).bullets.size(); j++)
				enemyships.get(i).bullets.get(j).soundEffect.playMusic();
		}
		
		for(int i = 0; i < playership.bullets.size(); i++)
		{
			playership.bullets.get(i).soundEffect2.playMusic();
		}
	}
	
	public void restart()
	{		
		objects = new ArrayList<GameObject>();
		//enemyships = new ArrayList<EnemyShip>();
		initializeData();
	}
				
}
