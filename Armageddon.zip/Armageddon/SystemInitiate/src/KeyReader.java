import java.util.BitSet;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.sound.sampled.*;

//Saner Turhaner

public class KeyReader implements KeyListener 
{
	//View
	ViewFacade frame;
	
	//Controller
	ControllerFacade controller_facade;
		
	//Bitset
	private BitSet keyBits;
	
	//Constructor
	public KeyReader(ViewFacade given, ControllerFacade given2)
	{ 
		//View initialized
		frame = given;
		
		//Controller initialized
		controller_facade = given2;
		
		keyBits = new BitSet(256);		
	}

	//Functions
	@Override
	public void keyPressed(KeyEvent event) 
	{
	    int keyCode = event.getKeyCode();
	    keyBits.set(keyCode);
	    
		//Escape
		if(KeyEvent.VK_ESCAPE == keyCode)
		{
			((GameScreenPanel)(frame.activePanel)).isPause = true;
			try 
			{	
				frame.model.stopMusics();
				((GameScreenPanel)(frame.activePanel)).removeKeyListener(frame.controller.activeReader);
				((GameScreenPanel)(frame.activePanel)).music.stopMusic();
				((GameScreenPanel)(frame.activePanel)).pausePanel.setVisible(true);
			}
		   	catch (Exception e) 
			{
		    	System.out.println("Exception is catched: " + e.getMessage());//Show the message of exception
			}
		}
		
		//Directions 
		if(isKeyPressed(KeyEvent.VK_LEFT))
		{
			try 
			{	
				frame.model.playership.goLeft();
			}
		   	catch (Exception e) 
			{
		    	System.out.println("Exception is catched: " + e.getMessage());//Show the message of exception
			}
		}
		if(isKeyPressed(KeyEvent.VK_RIGHT))
		{
			try 
			{	
				frame.model.playership.goRight();				
			}
		   	catch (Exception e) 
			{
		    	System.out.println("Exception is catched: " + e.getMessage());//Show the message of exception
			}
		}
		if(isKeyPressed(KeyEvent.VK_UP))
		{
			try 
			{	
				frame.model.playership.goUp();
			}
		   	catch (Exception e) 
			{
		    	System.out.println("Exception is catched: " + e.getMessage());//Show the message of exception
			}
		}
		if(isKeyPressed(KeyEvent.VK_DOWN))
		{
			try 
			{	
				frame.model.playership.goDown();
			}
		   	catch (Exception e) 
			{
		    	System.out.println("Exception is catched: " + e.getMessage());//Show the message of exception
			}
		}
		if(isKeyPressed(KeyEvent.VK_SPACE))
		{
			try 
			{	
				frame.model.playership.fire();
			}
		   	catch (Exception e) 
			{
		    	System.out.println("Exception is catched: " + e.getMessage());//Show the message of exception
			}
		}	
	}

	@Override
	public void keyReleased(KeyEvent event) 
	{		
		int keyCode = event.getKeyCode();//Take key code
	        
	    keyBits.clear(keyCode);//Clear		
	}

	@Override
	public void keyTyped(KeyEvent event) 
	{		    
		// TODO Auto-generated method stub	
	}
	
	public boolean isKeyPressed(final int keyCode) 
	{
	    return keyBits.get(keyCode);
	}
}