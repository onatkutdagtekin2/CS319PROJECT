import javax.swing.*;
import java.util.*;
import java.io.*;

//Author: Saner Turhaner

public class LoadLevelReader 
{
	//Variables
	ArrayList<String>list;
	
	//Constructors	
	public LoadLevelReader() throws IOException //With Parameters
	{
		list = new ArrayList<String>();//Emty Arraylist
		readScores("password.txt", list);//Fill the arraylist		
	}
	
	//Accessor Method
	public ArrayList<String> getList()
	{
		return list;
	}
	
	//Mutator Method
	public void setList(ArrayList<String>list)
	{
		this.list = list;
	}		
		
	//Necessary Methods
	public void readScores(String dosya, ArrayList<String>list) throws IOException//Read From File
    {      	
   		File myFile = new File(dosya);//File initialized
   		Scanner scan = new Scanner(myFile);//Scanner initialized
   		
   		String yeni = new String(); 
   		   		
   		while(scan.hasNextLine())
   		{
   			String line = scan.nextLine();
    		list.add(line);//Add to arraylist    		
   		}   		  		  			    		   		    	    		    		
    }
        	                
}  