/**
 * @(#)SystemInitiate.java
 *
 * Armageddon application
 *
 * @author Saner Turhaner
 * @version 1.00 2015/11/30
 */
 
public class SystemInitiate 
{    
    public static void main(String[] args) 
    {
    	ModelFacade model = new ModelFacade();	 
    	ViewFacade frame = new ViewFacade(model);
    	//Controller is created in ViewFacade
    }
}
