import java.awt.*;
import javax.swing.*;

//Saner Turhaner

public class SpaceShip extends GameObject//implements Drawable,Selectable
{	
	//Constructor
	public SpaceShip()
	{	
	}	
		
	//Necessary Methods
				
}
