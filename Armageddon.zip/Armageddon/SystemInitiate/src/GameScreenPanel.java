import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.sound.sampled.*;

//Saner Turhaner

public class GameScreenPanel extends JPanel
{
	//Frame
	ViewFacade frame;
	
	//Pause Panel
	PauseMenuPanel pausePanel;
	
	//Music
	SoundManager music;
	
	//HighScoreReader
	HighScoresReader highScores;
		
	//Labels
	JLabel score;
	JLabel scoreIntLabel;
	int scoreInt;
	JLabel level;
	JLabel levelIntLabel;
	int levelInt;
	
	//Progress Bars	
	JLabel fuelBar;
	JLabel shieldBar;
	static int minBar;
	static int maxBar;
	
	//Icons
	ImageIcon fuelImage;
	ImageIcon shieldImage;		
		
	//Timer
	Timer timer;
	int time;
	
	//Pause
	boolean isPause;
	
	//Constructor
	public GameScreenPanel(ViewFacade given) throws IOException
	{
		//See frame
		frame = given;
				
		//Play sound
		music = new SoundManager("game.mid");
		music.playMusic();
			
		//HighScoreReader
		highScores = frame.controller.activeInputProcessor.scoreReader;
	
		//Panel constructured
		setLayout(null);
		setBackground(Color.BLACK);
		setPreferredSize(new Dimension(1200,900));
		
		//Timer initialized
		TimerListener timeListener = new TimerListener();
		timer = new Timer(300, timeListener);
		time = 0;	
			
		//Labels initialized
		score = new JLabel( "Score: " );
		score.setFont(new Font("Calibri", Font.PLAIN, 30));
		score.setForeground(Color.RED);
		score.setBounds(20,20,120,30);
		score.setVisible(true);
		
		scoreInt = 0;
		scoreIntLabel = new JLabel( "" + scoreInt );
		scoreIntLabel.setFont(new Font("Calibri", Font.PLAIN, 30));
		scoreIntLabel.setForeground(Color.WHITE);
		scoreIntLabel.setBounds(110,20,120,30);
		scoreIntLabel.setVisible(true);
		
		level = new JLabel( "Level: " );
		level.setFont(new Font("Calibri", Font.PLAIN, 30));
		level.setForeground(Color.RED);
		level.setBounds(200,20,100,30);
		level.setVisible(true);
		
		levelInt = 1;
		levelIntLabel = new JLabel( "" + levelInt );
		levelIntLabel.setFont(new Font("Calibri", Font.PLAIN, 30));
		levelIntLabel.setForeground(Color.WHITE);
		levelIntLabel.setBounds(300,20,50,30);
		levelIntLabel.setVisible(true);
				
		fuelBar = new JLabel( frame.model.playership.fuel + " % " );
		fuelBar.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 24));
		fuelBar.setForeground(Color.YELLOW);
		fuelBar.setBounds(1000,858,150,24);
		fuelBar.setVisible(true);
		
		shieldBar = new JLabel( frame.model.playership.health + " % " );
		shieldBar.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 24));
		shieldBar.setForeground(Color.YELLOW);
		shieldBar.setBounds(750,858,150,24);
		shieldBar.setVisible(true);
		   		
		//Icons initialized
		fuelImage = new ImageIcon("Fuel.png");
		shieldImage = new ImageIcon("Shield.png");
		
		//KeyListener added
		addKeyListener(frame.controller.activeReader);
		setFocusable(true);	
		requestFocusInWindow(true);
		
		//Pause Panel
		pausePanel = new PauseMenuPanel(this);
		pausePanel.setSize(new Dimension(600,300));
		pausePanel.setLocation(300,300);
		pausePanel.setVisible(false);
		
		//Pause
		isPause = false;
			
		//Component
		add(pausePanel);	
		add(score);
		add(scoreIntLabel);
		add(level);
		add(levelIntLabel);
		add(fuelBar);
		add(shieldBar);
		
		//Start Game
		timer.start();
	}
		
	public void paintComponent(Graphics page)//Draw 
	{
		super.paintComponent(page);
			
		//Set Values Again
		shieldBar.setText( frame.model.playership.health + " % " );
		fuelBar.setText( frame.model.playership.fuel + " % " );	
		scoreIntLabel.setText( "" + frame.model.playership.points );	
		
		//Game Objects
		frame.model.background.draw(page);	
		frame.model.drawStars(page);
		frame.model.playership.draw(page);	
		frame.model.drawEnemies(page);
			
		if(!isPause)
		{				
			
			frame.model.playership.drawBullets(page);
			frame.model.drawEnemyBullets(page);		
			frame.model.moveStars();
			frame.model.moveEnemies();
		}
				
		frame.model.checkEnemyBullets(frame.model.playership, page);
		frame.model.checkPlayerBullets(frame.model.playership, page);
		frame.model.checkPlayerLife(page);
		
		//Icons 
		shieldImage.paintIcon(null,page,715,860);
		fuelImage.paintIcon(null,page,965,860);
		
		//Set Focusable
		setFocusable(true);	
		requestFocusInWindow(true);	
			
		//Repaint	
		repaint();						
	}
	
	//TimerListener	
	private class TimerListener implements ActionListener//Listener for timer
	{
		public void actionPerformed(ActionEvent event)//Time passing
		{
			if(true)//Always
			{	
				if(!isPause)
				{
					//Time increasing
					time++;
									
					//Playership
					if(time%1 == 0)//PlayerShip icon
					{	
						frame.model.playership.changeCurrent();	
						repaint();	
					}	
					if(time%12 == 0)//PlayerShip fuel
					{	
						frame.model.playership.fuelDecreasing();
						repaint();	
					}
					if(frame.model.playership.life == 0)//Game Over
					{	
						try 
				    	{ 
							gameOver();
						} 
						catch (IOException e)
						{						
							e.printStackTrace();
						}
					}		
							
					repaint();
				}									
			}
		}	
	}	
		
	//Necessary Methods
	public void restart()
	{				
		//Play sound
		music.stopMusic();		
		music = new SoundManager("game.mid");
		music.playMusic();		
		
		//Timer initialized
		time = 0;
		
		scoreInt = 0;
		levelInt = 1;		
		
		//Restart
		frame.model.restart();
		isPause = false;
		addKeyListener(frame.controller.activeReader);
		
		repaint();		
	}
	
		 	
	public void gameOver() throws IOException    	
	{
		isPause = true;
		timer.stop();		
		frame.model.stopMusics();
		((GameScreenPanel)(frame.activePanel)).removeKeyListener(frame.controller.activeReader);
		((GameScreenPanel)(frame.activePanel)).music.stopMusic();
						
		//HighScores
		highScores.checkScore( frame.model.playership.points );	
		
		//Back to Menu
		frame.setpanel(new MainMenuPanel(frame, frame.music));			
	}	
			
}
