import java.awt.*;
import javax.swing.*;

//Saner Turhaner

public class BackGround extends GameObject//implements Drawable,Selectable
{
	ImageIcon farIcon;
	
	//Constructor
	public BackGround()//With Parameter
	{
		icon = new ImageIcon("Background.png");				
	}		
}
