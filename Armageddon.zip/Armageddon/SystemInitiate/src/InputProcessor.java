import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.sound.sampled.*;

//Saner Turhaner

public class InputProcessor 
{
	//View
	ViewFacade frame;
	
	//Controller
	ControllerFacade controller_facade;
	
	//HighScoresReader
	HighScoresReader scoreReader;
	
	//LoadLevelReader
	LoadLevelReader passwordReader;
	
	//Constructor
	public InputProcessor(ViewFacade given, ControllerFacade given2)
	{ 
		//View initialized
		frame = given;
		
		//Controller initialized
		controller_facade = given2;
		
		//HighScoresReader initialized
		try 
		{				
			scoreReader = new HighScoresReader();
		}
	   	catch (Exception e) 
		{
		   	System.out.println("Exception is catched: " + e.getMessage());//Show the message of exception
		}
		
		
		//LoadLevelReader initialized
		try 
		{				
			passwordReader = new LoadLevelReader();
		}
	   	catch (Exception e) 
		{
		   	System.out.println("Exception is catched: " + e.getMessage());//Show the message of exception
		}
	}
	
	//Necessary Methods	
}