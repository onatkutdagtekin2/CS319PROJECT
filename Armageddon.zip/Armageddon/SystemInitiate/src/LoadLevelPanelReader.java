import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.sound.sampled.*;

//Saner Turhaner

public class LoadLevelPanelReader extends EventReader 
{			
	//Constructor
	public LoadLevelPanelReader(ViewFacade given, ControllerFacade given2)
	{ 
		super(given, given2);
	}
	
	//Function
	public void actionPerformed(ActionEvent event)//Takes event as a parameter
	{
		obj = event.getSource();
		
		try//Try it
    	{
    		if(obj == ((LoadLevelPanel)(frame.activePanel)).back)
			{
				frame.setpanel( new MainMenuPanel(frame, ((LoadLevelPanel)(frame.activePanel)).music) );
			}
			if(obj == ((LoadLevelPanel)(frame.activePanel)).submit)
			{
				if( ( (LoadLevelPanel)(frame.activePanel) ).password.equalsIgnoreCase( ( (LoadLevelPanel)(frame.activePanel) ).enterPassword.getText() ) )
				{			
					((LoadLevelPanel)(frame.activePanel)).music.stopMusic();		
					GameScreenPanel newPanel =  new GameScreenPanel(frame);
					newPanel.restart();
					frame.setpanel( newPanel );
				}					
			}
    	}	
    	catch(Exception exc)//If there is exception (general) catch it
    	{    		
    		System.out.println("Exception is catched: " + exc.getMessage());//Show the message of exception
    	}										
	}
}