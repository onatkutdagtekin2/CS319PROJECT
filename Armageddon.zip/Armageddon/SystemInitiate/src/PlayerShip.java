import java.awt.*;
import javax.swing.*;
import java.util.*;

//Saner Turhaner

public class PlayerShip extends SpaceShip//implements Drawable,Selectable
{
	ImageIcon icon1; 
	ImageIcon icon2; 
	ImageIcon life1;
	ImageIcon life2;
	ImageIcon life3;
	
	ArrayList<Bullet>bullets;
	int health;
	int fuel;
	int life;
	int points;
	
	//Constructor
	public PlayerShip(int lifegiven, int pointsgiven)//With Parameter
	{
		icon1 = new ImageIcon("PlayerShip.png");
		icon2 = new ImageIcon("PlayerShip2.png");
		life1 = new ImageIcon("Life.png");
		life2 = new ImageIcon("Life.png");
		life3 = new ImageIcon("Life.png");
		icon = icon1;
		
		//Speed
		speed = 4.2;
		
		//Health
		health = 100;
		life = lifegiven;
		points = pointsgiven;
		
		//Fuel
		fuel = 100;
			
		//Coordinates
		x = 100;
		y = 425;
		
		//Bullet
		bullets = new ArrayList<Bullet>();//Emty Arraylist		
	}	
		
	//Necessary Methods	
	public void changeCurrent()
	{
		if(icon == icon1)
			icon = icon2;
		else
			icon = icon1;
	}
	
	public void fire()
	{
		Bullet newBullet = new Bullet((int)(x + 82),(int)(y + 12));
		newBullet.setIcon();
		newBullet.soundEffect2.playMusic();
		bullets.add(newBullet);
	}
	
	public void drawBullets(Graphics g)//Draw all objects
	{		
		for(int i = 0; i < bullets.size(); i++)
			bullets.get(i).moveBullet();
			
		for(int i = 0; i < bullets.size(); i++)
			bullets.get(i).draw(g);
		
		deleteBullets();	
	}
	
	public void deleteBullets()//Delete
	{		
		for(int i = 0; i < bullets.size(); i++)
		{
			if(bullets.get(i).x > 2000)
			{
				bullets.get(i).soundEffect2.stopMusic();
				bullets.remove(i);
			}
		}			
	}
	
	public void drawLives(Graphics g)//Draw all objects
	{		
		if( life == 3 )
		{
			life1.paintIcon(null,g,1000,20);
			life2.paintIcon(null,g,1044,20);
			life3.paintIcon(null,g,1088,20);
		}
		else if( life == 2 )
		{
			life1.paintIcon(null,g,1200,20);
			life2.paintIcon(null,g,1044,20);
			life3.paintIcon(null,g,1088,20);
		}		
		else if( life == 1 )
		{
			life1.paintIcon(null,g,1200,20);
			life2.paintIcon(null,g,1200,20);
			life3.paintIcon(null,g,1088,20);
		}
		else if( life == 0 )
		{
			life1.paintIcon(null,g,1200,20);
			life2.paintIcon(null,g,1200,20);
			life3.paintIcon(null,g,1200,20);
		}	
	}
	
	public void damage()
	{
		health = health - 2;
	}
	
	public void die()
	{
		life = life - 1;
	}
	
	public void gainPoint()
	{
		points = points + 10;
	}
	
	public void fuelDecreasing()
	{
		fuel = fuel - 1;
	}
		
	//Directions
	public void goLeft()
	{
		if(x > 50)
			x = x - speed;
	}
	
	public void goRight()
	{
		if(x < 1070)
			x = x + speed;
	}
	
	public void goUp()
	{
		if(y > 80)
			y = y - speed;
	}
	
	public void goDown()
	{
		if(y < 800)
			y = y + speed;
	}
				
}
