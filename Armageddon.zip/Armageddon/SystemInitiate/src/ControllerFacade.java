import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

//Saner Turhaner

public class ControllerFacade 
{
	//ViewFacade
	ViewFacade frame;
	
	//Other Variables
	InputProcessor activeInputProcessor;
	KeyReader activeReader;
	EventReader eventHandler;
	
	//Constructor
	public ControllerFacade(ViewFacade given)
	{		
		//Frame
		frame = given;
		
		activeReader = new KeyReader(frame, this);
		activeInputProcessor = new InputProcessor(frame, this);
		eventHandler = new EventReader(frame, this);
	}	
	
	//Necessary Methods	
	public KeyReader getKeyReader() 
	{
		return this.activeReader;
	}
	
}
