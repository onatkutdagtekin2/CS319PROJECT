import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.sound.sampled.*;

//Saner Turhaner 

public class HighScoresPanel extends JPanel
{
	//Frame
	ViewFacade frame;
		
	//Music
	SoundManager music;
	    
	//ImageIcon
	ImageIcon background;
		
	//Labels
	JLabel title;
	JLabel indicators;
	JLabel label1;
	JLabel label2;
	JLabel label3;
	JLabel label4;
	JLabel label5;
	JLabel label6;
	JLabel label7;
	JLabel label8;
	JLabel label9;
	JLabel label10;
	
	//JButton
	JButton back;
	
	//Constructor
	public HighScoresPanel(ViewFacade given, SoundManager given3) throws IOException
	{
		//See frame
		frame = given;
			
		//Play sound
		music = given3;
			
		//Panel constructured
		setLayout(null);
		setBackground(Color.BLACK);
		setPreferredSize(new Dimension(1200,900));		
		
		//Information initialized
		background = new ImageIcon("armageddon.jpg");
					
		//Labels initialized
		title = new JLabel( "HIGH SCORES" );
		title.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 40));
		title.setForeground(Color.WHITE);
		title.setBounds(475,350,250,50);
		title.setVisible(true);
		
		indicators = new JLabel( "   Nick Name              Score" );
		indicators.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		indicators.setForeground(new Color(245,250,163));
		indicators.setBounds(180,420,600,30);
		indicators.setVisible(true);
		 
		label1 = new JLabel( ( (frame.controller.activeInputProcessor.scoreReader.getList()).get(0) ).toString() );
		label1.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		label1.setForeground(new Color(245,250,163));
		label1.setBounds(120,470,600,30);
		label1.setVisible(true);
		
		label2 = new JLabel( ( (frame.controller.activeInputProcessor.scoreReader.getList()).get(1) ).toString() );
		label2.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		label2.setForeground(new Color(245,250,163));
		label2.setBounds(120,510,600,30);
		label2.setVisible(true);
		
		label3 = new JLabel( ( (frame.controller.activeInputProcessor.scoreReader.getList()).get(2) ).toString() );
		label3.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		label3.setForeground(new Color(245,250,163));
		label3.setBounds(120,550,600,30);
		label3.setVisible(true);	
		
		label4 = new JLabel( ( (frame.controller.activeInputProcessor.scoreReader.getList()).get(3) ).toString() );
		label4.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		label4.setForeground(new Color(245,250,163));
		label4.setBounds(120,590,600,30);
		label4.setVisible(true);
		
		label5 = new JLabel( ( (frame.controller.activeInputProcessor.scoreReader.getList()).get(4) ).toString() );
		label5.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		label5.setForeground(new Color(245,250,163));
		label5.setBounds(120,630,600,30);
		label5.setVisible(true);
		
		label6 = new JLabel( ( (frame.controller.activeInputProcessor.scoreReader.getList()).get(5) ).toString() );
		label6.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		label6.setForeground(new Color(245,250,163));
		label6.setBounds(120,670,600,30);
		label6.setVisible(true);
		
		label7 = new JLabel( ( (frame.controller.activeInputProcessor.scoreReader.getList()).get(6) ).toString() );
		label7.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		label7.setForeground(new Color(245,250,163));
		label7.setBounds(120,710,600,30);
		label7.setVisible(true);
		
		label8 = new JLabel( ( (frame.controller.activeInputProcessor.scoreReader.getList()).get(7) ).toString() );
		label8.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		label8.setForeground(new Color(245,250,163));
		label8.setBounds(120,750,600,30);
		label8.setVisible(true);
		
		label9 = new JLabel( ( (frame.controller.activeInputProcessor.scoreReader.getList()).get(8) ).toString() );
		label9.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		label9.setForeground(new Color(245,250,163));
		label9.setBounds(120,790,600,30);
		label9.setVisible(true);
		
		label10 = new JLabel( ( (frame.controller.activeInputProcessor.scoreReader.getList()).get(9) ).toString() );
		label10.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		label10.setForeground(new Color(245,250,163));
		label10.setBounds(120,830,600,30);
		label10.setVisible(true);
					
		//Button initialized
		back = new JButton("Back to Menu");
		back.setOpaque(false);
		back.setBorderPainted(false);
		back.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		back.setLocation(950,800);
		back.setSize(200,50);	
		back.addActionListener(new HighScoresPanelReader(frame, frame.controller));
			
		//Adding Components
		add(back);
		add(title);
		add(indicators);
		add(label1);
		add(label2);
		add(label3);
		add(label4);
		add(label5);
		add(label6);
		add(label7);
		add(label8);
		add(label9);
		add(label10);			   	 
	}
	
	public void paintComponent(Graphics page)//Drawing cards
	{
		super.paintComponent(page);//Default (must)
		
		//Draw Background
		background.paintIcon(null,page,0,0);		
	}
				
}