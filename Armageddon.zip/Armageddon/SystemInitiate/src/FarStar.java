import java.awt.*;
import javax.swing.*;

//Saner Turhaner

public class FarStar extends GameObject//implements Drawable,Selectable
{
	//Constructor
	public FarStar()//With Parameter
	{
		icon = new ImageIcon("FarStar.png");
		speed = 0.4;
			
		//Coordinates
		x = (int)( Math.random() * 120000 );
		y = (int)( Math.random() * 900 );		
	}	
		
	//Necessary Methods
	public void move()
	{
		x = x - speed;
	}
	
}
