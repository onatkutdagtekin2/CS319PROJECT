import javax.swing.*;

//Saner Turhaner

public class ViewFacade extends JFrame
{	
	//Controller
	ControllerFacade controller;
	
	//Model
	ModelFacade model;
	
	//Panel
	JPanel activePanel;
	
	//Music
    SoundManager music;
    
	//Constructor
	public ViewFacade(ModelFacade given2)
	{
		//Controller initialized		
    	controller = new ControllerFacade(this);
		
		//Model initialized
		model = given2;
		
		//Frame initialized
		setTitle("Armageddon");
        setSize(1200,900);	
		setResizable(false);//Not changable
        setVisible(true);			
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	 
			
		//Music initialized
		music = new SoundManager("menu.mid");
		
		//Active Panel
		activePanel = new MainMenuPanel(this, music);  
    	add(activePanel);  
		
		pack();
	}	
	
	//Necessary Methods	
	public void setpanel(JPanel panel)//Change the panel
	{
		activePanel = panel;
	    getContentPane().removeAll();
	    getContentPane().add(panel);
	    getContentPane().revalidate();
	    getContentPane().repaint();
	}
		
	public void exit()//dispose() method exit from frame
	{
		dispose();
	}			
	
}	