import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.sound.sampled.*;

//Saner Turhaner

public class HighScoresPanelReader extends EventReader 
{			
	//Constructor
	public HighScoresPanelReader(ViewFacade given, ControllerFacade given2)
	{ 
		super(given, given2);
	}
	
	//Function
	public void actionPerformed(ActionEvent event)//Takes event as a parameter
	{
		obj = event.getSource();
		
		try//Try it
    	{
    		if(obj == ((HighScoresPanel)(frame.activePanel)).back)
			{
				frame.setpanel( new MainMenuPanel(frame, ((HighScoresPanel)(frame.activePanel)).music) );
			}
    	}	
    	catch(Exception exc)//If there is exception (general) catch it
    	{    		
    		System.out.println("Exception is catched: " + exc.getMessage());//Show the message of exception
    	}										
	}
}