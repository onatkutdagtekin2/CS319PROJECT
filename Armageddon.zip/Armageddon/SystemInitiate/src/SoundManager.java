import java.awt.*;
import javax.swing.*;
import java.io.*;
import javax.sound.sampled.*;

//Saner Turhaner

public class SoundManager
{	
	//Sound
	File yourFile;
    AudioInputStream stream;
    AudioFormat format;
    DataLine.Info info;
    Clip clip;
	
	//isPlay
	boolean isPlay;
	
	//Constructor
	public SoundManager(String given)
	{		
		//Sound
		try 
		{
    		yourFile = new File(given);
    		stream = AudioSystem.getAudioInputStream(yourFile);
    		format = stream.getFormat();
    		info = new DataLine.Info(Clip.class, format);
    		clip = (Clip) AudioSystem.getLine(info);
    		clip.open(stream);
		}
		catch (Exception e) 
		{
    		System.out.println("Exception is catched: " + e.getMessage());//Show the message of exception
		}	
		
		//IsPlay			
		isPlay = false;		
	}
	
	//Necessary Methods
	public void playMusic()
	{
		isPlay = true;
		
		clip.loop(1000000);	
	}
	
	public void stopMusic()
	{
		clip.stop();	
	}
	
	public void setVolume(int x)
	{		
		//clip.open(audioInputStream);
		FloatControl gainControl = (FloatControl)clip.getControl(FloatControl.Type.MASTER_GAIN);
		gainControl.setValue(-10.0f); // Reduce volume by 10 decibels.
	}	
			
	public boolean getIsPlay()//Getter
	{
		return isPlay;	
	}		
	
	public void setIsPlay(boolean given)//Setter
	{
		isPlay = given;
	}	
			
}