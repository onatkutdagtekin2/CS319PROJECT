import java.awt.*;
import javax.swing.*;

//Saner Turhaner

public class GameObject //implements Drawable,Selectable
{
	//Variables
	//ImageIcons
	ImageIcon icon;
	
	//Integer Variables
	double speed;
	
	//Coordinates
	double x;
	double y;
	
	//Size
	int width;
	int height;
	
	//Constructor
	public GameObject()
	{	
	}	
		
	//Necessary Methods		
	//Implementing drawable interface
	public void draw(Graphics g)
	{
		icon.paintIcon(null,g,(int)x,(int)y);
	}
	
	// Methods for being locatable
	public double getX() // returns x
	{
		return x;
	}

	public double getY() // returns y
	{
		return y;
	}

	public void setLocation(int givenX, int givenY)//Setting locations
	{
		x = givenX;
		y = givenY;
	}
	
	public void move()
	{
		x = x - speed;
	}
		
}
