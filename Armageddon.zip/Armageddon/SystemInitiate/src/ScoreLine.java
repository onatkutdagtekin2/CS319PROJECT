
//Author: Saner Turhaner

public class ScoreLine 
{
	//Variables	
	String name;
	int order;
	int point;
		
	//Constructors
	public ScoreLine()//Default
	{
		name = "";
		order = 0;
		point = 0;			
	}
	
	public ScoreLine(int order, String name, int point)//With Parameters
	{		
		this.order = order;
		this.name = name;
		this.point = point;			
	}
	
	//Mutator Method
	public void setName(String given)
	{
		name = given;
	}
		
	public void setOrder(int order)
	{
		this.order = order;
	}
		
	
	//Accessors Methods
	public String getName()
	{
		return name;
	}
		
	public int getOrder()
	{
		return order;
	}
	
	public int getPoint()
	{ 
		return point;		
	}	
		
	//Necessary Method
	public String toString()//Print out the features
	{
		String returned = String.format("%-10s %-20s %-20s", (order + 1) + ".", name, point);  
		return returned;	
	}
		
}