import java.awt.*;
import javax.swing.*;
import java.util.*;

//Saner Turhaner

public class Bullet extends GameObject//implements Drawable,Selectable
{
	ImageIcon icon1;
	ImageIcon icon2;
	ImageIcon blast;
		
	SoundManager soundEffect;
	SoundManager soundEffect2;
	SoundManager soundEffect3;//Blast
	
	//Constructor
	public Bullet(int givenx, int giveny)//With Parameter
	{
		icon1 = new ImageIcon("Bullet.png");
		icon2 = new ImageIcon("Bullet2.png");
		blast = new ImageIcon("Blast.png");
		icon = icon1;
				
		//Speed
		speed = 15;
					
		//Coordinates
		x = givenx;
		y = giveny;
		
		//Sound
		soundEffect = new SoundManager("laser.wav");
		soundEffect2 = new SoundManager("laser2.wav");
		soundEffect3 = new SoundManager("blast.wav");	
	}	
		
	//Necessary Methods
	
	public void explose(Graphics g)
	{		
		blast.paintIcon(null,g,(int)x,(int)y);
		soundEffect3.playMusic();
	}
	
	public void setIcon()
	{
		icon = icon2;
	}
	
	public void moveBullet()
	{
		x = x + speed;
	}
	
	public void moveToPlayerBullet()
	{
		x = x - speed/3;
	}
		
}
