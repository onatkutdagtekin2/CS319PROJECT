import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.sound.sampled.*;

//Saner Turhaner

public class EventReader implements ActionListener 
{	
	//View
	ViewFacade frame;
	
	//Controller
	ControllerFacade controller_facade;
	
	//Object
	Object obj;
		
	//Constructor
	public EventReader(ViewFacade given, ControllerFacade given2)
	{ 
		//View initialized
		frame = given;
		
		//Controller initialized
		controller_facade = given2;
	}
	
	//Function
	public void actionPerformed(ActionEvent event)//Takes event as a parameter
	{
		//obj = event.getSource();										
	}
}