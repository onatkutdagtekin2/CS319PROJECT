import java.awt.*;
import javax.swing.*;

//Saner Turhaner

public class Station extends GameObject//implements Drawable,Selectable
{
	//Constructor
	public Station()//With Parameter
	{
		icon = new ImageIcon("Station.png");
			
		//Coordinates
		x = (int)( Math.random() * 520 );
		y = -60;		
	}	
		
	//Necessary Methods
	
}
