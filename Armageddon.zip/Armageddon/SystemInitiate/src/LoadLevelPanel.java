import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.sound.sampled.*;

//Saner Turhaner
//JButton with only text:
//***********		button.setContentAreaFilled(false);        
//***********		button.setFocusPainted(false);
//***********		button.setBorder(BorderFactory.createEmptyBorder());

public class LoadLevelPanel extends JPanel
{
	//Frame
	ViewFacade frame;
	
	//Music
	SoundManager music;
		
	//String
	String password;
		
	//JButtons
	JButton back;
	JButton submit;
	
	//Labels
	JLabel title;
	JLabel expression;
	
	//Text Field
	JTextField enterPassword;
	
	//Background
	ImageIcon background;
		
	//Constructor
	public LoadLevelPanel(ViewFacade given, SoundManager given3)
	{				
		//See frame
		frame = given;
					
		//Play sound
		music = given3;
		
		//Panel Constructured
		setLayout(null);
		setPreferredSize(new Dimension(1200,900));
		setBackground(Color.BLACK);
				
		//Welcome initialized
		background = new ImageIcon("armageddon.jpg");
				
		//Buttons initialized
		back = new JButton("Back to Menu");
		back.setOpaque(false);
		back.setBorderPainted(false);
		back.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		back.setLocation(950,800);
		back.setSize(200,50);	
		back.addActionListener(new LoadLevelPanelReader(frame, frame.controller));
		
		submit = new JButton("Submit");
		submit.setOpaque(false);
		submit.setBorderPainted(false);
		submit.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		submit.setLocation(500,600);
		submit.setSize(200,50);	
		submit.addActionListener(new LoadLevelPanelReader(frame, frame.controller));
			
		//TextField Initialized
		enterPassword = new JTextField(20);
		enterPassword.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 35));
		enterPassword.setLocation(300,500);
		enterPassword.setSize(600,80);	
		enterPassword.addActionListener(new LoadLevelPanelReader(frame, frame.controller));
		
		//Labels initialized
		title = new JLabel( "PASSWORD" );
		title.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 40));
		title.setForeground(Color.WHITE);
		title.setBounds(500,350,250,50);
		title.setVisible(true);
		
		expression = new JLabel( "Please enter the password given at the end of the game" );
		expression.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		expression.setForeground(Color.WHITE);
		expression.setBounds(300,420,600,50);
		expression.setVisible(true);
			
		//String
		password = (frame.controller.activeInputProcessor.passwordReader.getList().get(0));
						
		//Add components in panel
		add(title);
		add(expression);
		add(enterPassword);
		add(submit);
		add(back);
	}
	
	public void paintComponent(Graphics page)//Drawing cards
	{
		super.paintComponent(page);//Default (must)
		
		//Draw Background
		background.paintIcon(null,page,0,0);		
	}
		
}
