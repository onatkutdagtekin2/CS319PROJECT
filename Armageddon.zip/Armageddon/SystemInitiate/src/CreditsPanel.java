import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.sound.sampled.*;

//Saner Turhaner
//JButton with only text:
//***********		button.setContentAreaFilled(false);        
//***********		button.setFocusPainted(false);
//***********		button.setBorder(BorderFactory.createEmptyBorder());

public class CreditsPanel extends JPanel
{
	//Frame
	ViewFacade frame;
	
	//Music
	SoundManager music;
	
	//JButtons
	JButton back;
	
	//Labels
	JLabel title;
	
	//Text Area
	JTextArea credits;
		
	//Background
	ImageIcon background;
		
	//Constructor
	public CreditsPanel(ViewFacade given, SoundManager given2)
	{				
		//See frame
		frame = given;
			
		//Play sound
		music = given2;
				
		//Panel Constructured
		setLayout(null);
		setPreferredSize(new Dimension(1200,900));
		setBackground(Color.BLACK);
				
		//Welcome initialized
		background = new ImageIcon("armageddon.jpg");
				
		//Buttons initialized
		back = new JButton("Back to Menu");
		back.setOpaque(false);
		back.setBorderPainted(false);
		back.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		back.setLocation(950,800);
		back.setSize(200,50);	
		back.addActionListener(new CreditsPanelReader(frame,frame.controller));
				
		//Labels initialized
		title = new JLabel( "CREDITS" );
		title.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 40));
		title.setForeground(Color.WHITE);
		title.setBounds(540,350,250,50);
		title.setVisible(true);
		
		//TextArea initialized
		credits = new JTextArea(
		    "CS 319 - Object-Oriented Software Engineering\n" + 	
		    "                      Group 4, Section 2\n " + 
		    "	Armageddon\n\n" + 	
		    "	Designers:\n " +
		    "�zge Karaaslan	21301835\n " +
		    "Onatkut Da�tekin 	21300801\n " +
		    "Teyfik Rumelli		21102161\n " + 
		    "Saner Turhaner	21100475"	
		);	
		credits.setFont(new Font("Calibri", Font.PLAIN + Font.BOLD, 25));
		credits.setLocation(300,450);
		credits.setSize(600,300);
		credits.setEditable(false);	
								
		//Add components in panel
		add(title);
		add(credits);
		add(back);
	}
	
	public void paintComponent(Graphics page)//Drawing cards
	{
		super.paintComponent(page);//Default (must)
		
		//Draw Background
		background.paintIcon(null,page,0,0);		
	}
				
}
