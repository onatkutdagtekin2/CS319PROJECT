import javax.swing.*;
import java.util.*;
import java.io.*;

//Author: Saner Turhaner

public class HighScoresReader 
{
	//Variables
	ArrayList<ScoreLine>list;
	
	//Constructors	
	public HighScoresReader() throws IOException //With Parameters
	{
		list = new ArrayList<ScoreLine>();//Emty Arraylist
		readScores("highscores.txt", list);//Fill the arraylist		
	}
	
	//Accessor Method
	public ArrayList<ScoreLine> getList()
	{
		return list;
	}
	
	//Mutator Method
	public void setList(ArrayList<ScoreLine>list)
	{
		this.list = list;
	}		
		
	//Necessary Methods
	public void readScores(String dosya, ArrayList<ScoreLine>list) throws IOException//Read From File
    {      	
   		File myFile = new File(dosya);//File initialized
   		Scanner scan = new Scanner(myFile);//Scanner initialized
   		
   		ScoreLine yeni = new ScoreLine(); 
   		   		
   		while(scan.hasNextLine())
   		{
   			String line = scan.nextLine();
   			String[] words = line.split(",");//Take every word
   			   			
    		yeni = new ScoreLine( Integer.parseInt(words[0]), words[1], Integer.parseInt(words[2]) );//Create a new scoreline
    		list.add(yeni);//Add to arraylist    		
   		}   		  		  			    		   		    	    		    		
    }
    
	public void checkScore(int point) throws IOException//Just check if he enters the Highscores table
    {
    	if( point >= ( list.get(9) ).getPoint() )
    	{
    		String input;
    		input = JOptionPane.showInputDialog(null,"Congratulations !, your point is " + point + "\nEnter the Name: ");
    		
    		ScoreLine newOne = new ScoreLine( determineOrder(point), input, point );//Created
    		addToList(newOne);//Add in highscore list
    	}
    	else
    	{
    		System.out.print("girildi");    			
    		JOptionPane.showMessageDialog(null, "Game Over !, your point is " + point);
    		
    	}	
    }
    	
    public int determineOrder(int point) throws IOException//Determine the s�ra of the user
    {
    	int order = -1;//Temporaly
    	
    	for(int i = 9; i >= 0; i--)//Scan list    		
    	{    		
    		if( point >= ( list.get(i) ).getPoint() )
    		{    			
    			order =  ( list.get(i) ).getOrder();//Return s�ra number    			
    		}
    	}
    	
    	return order;
    }
    
    public void addToList(ScoreLine x) throws IOException
    {		
    	int begin = x.getOrder();//Slope the order
    	
    	for(int i = 8; i >= begin; i--)
    	{
    		( list.get(i) ).setOrder( ( list.get(i) ).getOrder() + 1 );
    		list.set( i + 1 , list.get(i) );//Yeri kayd�		
    	}
    	
    	list.remove( begin );//Remove last one
    	list.add( begin, x );//Add in current index
    	
    	writeInFile(list, "highscores.txt");		
    }
    
    public void writeInFile(ArrayList<ScoreLine>list, String dosya)throws IOException//Dosyaya yaz�lacak		
    {
    	try 
    	{ 
    		String content = "";//Temporaly
    		
    		for(int i = 0; i < list.size(); i++)//Write in "highscores.txt"
    			content = content 
    						+   (list.get(i)).getOrder()  + "," 
    						+	(list.get(i)).getName()   + ","  
    						+	(list.get(i)).getPoint()  + "\n";
			 
			File file = new File(dosya);			
			PrintWriter writer = new PrintWriter(file);
			writer.print(content);
			writer.close();
		} 
		catch (IOException e)
		{						
			e.printStackTrace();
		}	 					
    } 
        	                
}  