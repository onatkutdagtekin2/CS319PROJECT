import java.awt.*;
import javax.swing.*;

//Saner Turhaner

public class CloseStar extends GameObject//implements Drawable,Selectable
{
	//Constructor
	public CloseStar()//With Parameter
	{
		icon = new ImageIcon("CloseStar.png");
		speed = 1;
		
		//Coordinates
		x = (int)( Math.random() * 300000 );
		y = (int)( Math.random() * 900 );	
	}	
		
	//Necessary Methods
	public void move()
	{
		x = x - speed;
	}
	
}
