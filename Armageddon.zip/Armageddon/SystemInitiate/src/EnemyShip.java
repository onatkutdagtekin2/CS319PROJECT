import java.awt.*;
import javax.swing.*;
import java.util.*;

//Saner Turhaner

public class EnemyShip extends SpaceShip//implements Drawable,Selectable
{
	ArrayList<Bullet>bullets;
	
	double firsty;
	boolean goUp;
	
	int health;
	
	//Constructor
	public EnemyShip()//With Parameter
	{
		icon = new ImageIcon("EnemyShip.png");
			
		speed = 0.6;
		health = 10;
		
		//Coordinates
		x = 1200 + (int)( Math.random() * 300 );
		y = 200 + (int)( Math.random() * 500 );
		firsty = y;
		goUp = true;
		
		//Bullet
		bullets = new ArrayList<Bullet>();//Emty Arraylist			
	}	
			
	//Necessary Methods
	public void movement()
	{
		if( x > 1050 )
			x = x - speed;
		else
		{
			rotate();
			//fire();
		}
	}
	
	public void movement2()
	{
		if( x > 950 )
			x = x - speed;
		else
			rotate();
	}
	
	public void fire()
	{
		Bullet newBullet = new Bullet((int)(x - 51),(int)(y + 9));
		newBullet.soundEffect.playMusic();
		bullets.add(newBullet);
	}
	
	public void drawBullets(Graphics g)//Draw all objects
	{		
		for(int i = 0; i < bullets.size(); i++)
			bullets.get(i).moveToPlayerBullet();
			
		for(int i = 0; i < bullets.size(); i++)
			bullets.get(i).draw(g);
		
		deleteBullets();	
	}
	
	public void deleteBullets()//Delete
	{		
		for(int i = 0; i < bullets.size(); i++)
		{
			if(bullets.get(i).x < -1200)
			{
				bullets.get(i).soundEffect.stopMusic();
				bullets.remove(i);
			}
		}			
	}
	
	public void checkCollisionForPlayer(PlayerShip ship, Graphics g)
	{		
		for(int i = 0; i < bullets.size(); i++)
		{
			if( (bullets.get(i).x < ship.x + 82) && ( bullets.get(i).y + 4 > ship.y && bullets.get(i).y < ship.y + 23 ) )//Collision
			{
				ship.damage();
				bullets.get(i).explose(g);
				bullets.get(i).soundEffect3.stopMusic();
				bullets.get(i).soundEffect.stopMusic();
				bullets.remove(i);
			}
		}			
	}
	
	public void checkCollisionForEnemy(PlayerShip ship, Graphics g)
	{		
		for(int i = 0; i < ship.bullets.size(); i++)
		{
			if( (ship.bullets.get(i).x + 27 > x) && ( ship.bullets.get(i).y + 5 > y && ship.bullets.get(i).y < y + 19 ) )//Collision
			{
				damage();
				ship.bullets.get(i).explose(g);
				ship.bullets.get(i).soundEffect3.stopMusic();
				ship.bullets.get(i).soundEffect2.stopMusic();
				ship.bullets.remove(i);
			}
		}			
	}
	
	public void damage()
	{
		health = health - 8;
	}
	
	//Directions
	public void rotate()
	{
		lookGoUp();
		
		if( goUp )
			y = y - speed;
		else
			y = y + speed;
		
		if( y < firsty + 60.6 && y > firsty + 59.4 )			
			fire();
	}
	
	public void lookGoUp()
	{
		if( y > firsty + 120 )
			goUp = true;
		if( y < firsty - 120 )
			goUp = false;
	}
			
}
