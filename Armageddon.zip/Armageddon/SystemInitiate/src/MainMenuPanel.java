import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.sound.sampled.*;

//Saner Turhaner
//JButton with only text:
//***********		button.setContentAreaFilled(false);        
//***********		button.setFocusPainted(false);
//***********		button.setBorder(BorderFactory.createEmptyBorder());

public class MainMenuPanel extends JPanel
{
	//Frame
	ViewFacade frame;
	
	//Music
	SoundManager music;
	
	//JButtons
	JButton newGame;
	JButton password;
	JButton highScores;
	JButton credits;
	JButton exit;
	
	//Background
	ImageIcon background;
	
	//Constructor
	public MainMenuPanel(ViewFacade given, SoundManager given2)
	{				
		//See frame
		frame = given;
				
		//Play sound
		music = given2;
		music.playMusic();
			
		//Panel Constructured
		setLayout(null);
		setPreferredSize(new Dimension(1200,900));
		setBackground(Color.BLACK);
				
		//Welcome initialized
		background = new ImageIcon("armageddon.jpg");
		
		//JButtons initialized
		newGame = new JButton("Newgame");
		newGame.setSize(new Dimension(300,50));
		newGame.setLocation(450,400);
		newGame.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN + Font.BOLD, 30));
		newGame.setForeground(Color.BLACK);
        newGame.setFocusPainted(false);
        
		password = new JButton("Password");
		password.setSize(new Dimension(300,50));
		password.setLocation(450,470);
		password.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN + Font.BOLD, 30));
		password.setForeground(Color.BLACK);
        password.setFocusPainted(false);
        
		highScores = new JButton("Highscores");
		highScores.setSize(new Dimension(300,50));
		highScores.setLocation(450,540);
		highScores.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN + Font.BOLD, 30));
		highScores.setForeground(Color.BLACK);
        highScores.setFocusPainted(false);
		
		credits = new JButton("Credits");
		credits.setSize(new Dimension(300,50));
		credits.setLocation(450,610);
		credits.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN + Font.BOLD, 30));
		credits.setForeground(Color.BLACK);
        credits.setFocusPainted(false);
        
		exit = new JButton("Exit");
		exit.setSize(new Dimension(300,50));
		exit.setLocation(450,680);
		exit.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN + Font.BOLD, 30));
		exit.setForeground(Color.BLACK);
        exit.setFocusPainted(false);
		
		//Add listener to buttons
		newGame.addActionListener(new MainMenuPanelReader(frame, frame.controller));
		password.addActionListener(new MainMenuPanelReader(frame, frame.controller));
		highScores.addActionListener(new MainMenuPanelReader(frame, frame.controller));
		credits.addActionListener(new MainMenuPanelReader(frame, frame.controller));
		exit.addActionListener(new MainMenuPanelReader(frame, frame.controller));
		
		//Add components in panel
		add(newGame);
		add(password);
		add(highScores);
		add(credits);
		add(exit);
	}
	
	public void paintComponent(Graphics page)//Drawing cards
	{
		super.paintComponent(page);//Default (must)
		
		//Draw Background
		background.paintIcon(null,page,0,0);		
	}
	
}